import pg from "pg";

// Pool único por processo (também sobrevive ao hot reload em desenvolvimento).
const g = globalThis as unknown as { __radarPool?: pg.Pool };

// NUMERIC e BIGINT chegam como string por padrão; mantemos assim para não perder precisão. Contagens usam ::int nas consultas.
export function getPool(): pg.Pool {
  if (!g.__radarPool) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error("DATABASE_URL não definida (veja .env.example).");
    g.__radarPool = new pg.Pool({ connectionString: url, max: 5, idleTimeoutMillis: 30_000, statement_timeout: 15_000 });
    g.__radarPool.on("error", () => { /* conexão ociosa caiu: o pool reabre na próxima consulta */ });
  }
  return g.__radarPool;
}
