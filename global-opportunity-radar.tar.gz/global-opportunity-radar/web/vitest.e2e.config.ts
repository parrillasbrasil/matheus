import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: { environment: "node", include: ["tests/e2e/**/*.e2e.ts"], testTimeout: 60000, hookTimeout: 120000, fileParallelism: false },
});
